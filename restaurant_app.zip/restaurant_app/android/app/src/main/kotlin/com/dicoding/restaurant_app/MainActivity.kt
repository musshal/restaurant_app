package com.dicoding.restaurant_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
